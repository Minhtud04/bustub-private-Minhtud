//===----------------------------------------------------------------------===//
//
//                         BusTub
//
// hyperloglog_presto.cpp
//
// Identification: src/primer/hyperloglog_presto.cpp
//
// Copyright (c) 2015-2025, Carnegie Mellon University Database Group
//
//===----------------------------------------------------------------------===//

#include "primer/hyperloglog_presto.h"

namespace bustub {

/** @brief Parameterized constructor. */
template <typename KeyType>
HyperLogLogPresto<KeyType>::HyperLogLogPresto(int16_t n_leading_bits) : cardinality_(0) {
  if (n_leading_bits < 0) {
    this->valid_lead_bit_ = false;
  } else {
    this->valid_lead_bit_ = true;
    this->lead_bit_ = static_cast<uint16_t>(n_leading_bits);
    uint16_t register_size = std::pow(2, this->lead_bit_);
    auto start_val = std::bitset<DENSE_BUCKET_SIZE>(0);
    for (int i = 0; i < register_size; i++) {
      dense_bucket_.push_back(start_val);
    };  // fix size 4-bit * n_leading_bits^2.
  }
}

/** @brief get bit representation */
template <typename KeyType>
auto HyperLogLogPresto<KeyType>::GetBitSetRepresentation(KeyType &val) -> uint64_t {
  hash_t hash_val = CalculateHash(val);
  auto converted_hash = static_cast<uint64_t>(hash_val);
  return converted_hash;
};

/** @brief calculate the register index */
template <typename KeyType>
auto HyperLogLogPresto<KeyType>::GetRegisterIndex(uint64_t &hash_bit) -> uint16_t {
  int shift = BITSET_CAPACITY - this->lead_bit_;
  return static_cast<uint16_t>(hash_bit >> shift);
};

/** @brief Get previous value from overflow and current value bucket*/
template <typename KeyType>
auto HyperLogLogPresto<KeyType>::GetPrevValueAtRegisterIndex(int16_t &register_index) -> int8_t {
  auto val = static_cast<int8_t>(this->dense_bucket_[register_index].to_ulong());
  if (this->overflow_bucket_.find(register_index) != this->overflow_bucket_.end()) {
    val = (static_cast<int8_t>(this->overflow_bucket_[register_index].to_ulong()) << DENSE_BUCKET_SIZE) | val;
  }
  return val;
}

/** @brief Get current value from the hashBit - LSBs */
template <typename KeyType>
auto HyperLogLogPresto<KeyType>::GetCurrentValue(uint64_t &hashbit) -> int8_t {
  int8_t count = 0;
  uint64_t mask = 1;
  while (count < BITSET_CAPACITY - this->lead_bit_) {
    if (((hashbit >> count) & mask) == 1) {
      break;
    }
    count += 1;
  }
  return count;
}

/** @brief */
template <typename KeyType>
auto HyperLogLogPresto<KeyType>::UpdateValue(int8_t &cur_val, int16_t &register_index) -> void {
  std::bitset<DENSE_BUCKET_SIZE> val(cur_val & 0x0F);
  this->dense_bucket_[register_index] = val;

  uint8_t overflow_val = cur_val >> DENSE_BUCKET_SIZE;
  if (overflow_val > 0) {
    std::bitset<OVERFLOW_BUCKET_SIZE> overflow(overflow_val);
    this->overflow_bucket_[register_index] = overflow;
  }
}

/** @brief Element is added for HLL calculation. */
template <typename KeyType>
auto HyperLogLogPresto<KeyType>::AddElem(KeyType val) -> void {
  /** @TODO(student) Implement this function! */
  if (!this->valid_lead_bit_) {
    return;
  }
  uint64_t bit_hash = GetBitSetRepresentation(val);
  int16_t register_index = GetRegisterIndex(bit_hash);
  int8_t prev_val = GetPrevValueAtRegisterIndex(register_index);
  int8_t cur_val = GetCurrentValue(bit_hash);

  if (cur_val > prev_val) {
    UpdateValue(cur_val, register_index);
  }
}

/** @brief Function to compute cardinality. */
template <typename T>
auto HyperLogLogPresto<T>::ComputeCardinality() -> void {
  /** @TODO(student) Implement this function! */
  if (!this->valid_lead_bit_) {
    return;
  }
  double sum_value = 0;
  double cur_val;
  int16_t bucket_size = this->dense_bucket_.size();
  int16_t i;
  for (i = 0; i < bucket_size; i++) {
    cur_val = std::pow(2, -GetPrevValueAtRegisterIndex(i));
    sum_value += cur_val;
  }
  this->cardinality_ = (CONSTANT * bucket_size * bucket_size / sum_value);
}

template class HyperLogLogPresto<int64_t>;
template class HyperLogLogPresto<std::string>;
}  // namespace bustub
