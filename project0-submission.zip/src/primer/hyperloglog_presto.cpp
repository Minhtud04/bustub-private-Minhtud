//===----------------------------------------------------------------------===//
//
//                         BusTub
//
// hyperloglog_presto.cpp
//
// Identification: src/primer/hyperloglog_presto.cpp
//
// Copyright (c) 2015-2025, Carnegie Mellon University Database Group
//
//===----------------------------------------------------------------------===//

#include "primer/hyperloglog_presto.h"

namespace bustub {

/** @brief Parameterized constructor. */
template <typename KeyType>
HyperLogLogPresto<KeyType>::HyperLogLogPresto(int16_t n_leading_bits) : cardinality_(0) {
  if (n_leading_bits < 0) {
    valid_lead_bit = false;
  } else {
    valid_lead_bit = true;
    lead_bit = static_cast<uint16_t>(n_leading_bits);
    uint16_t registerSize = std::pow(2, lead_bit);
    std::bitset<DENSE_BUCKET_SIZE> startVal = std::bitset<DENSE_BUCKET_SIZE>(0);
    for (int i = 0; i < registerSize; i++) {
      dense_bucket_.push_back(startVal);
    };  // fix size 4-bit * n_leading_bits^2.
  }
}

/** @brief get bit representation */
template <typename KeyType>
auto HyperLogLogPresto<KeyType>::GetBitSetRepresentation(KeyType &val) -> uint64_t {
  hash_t hashVal = CalculateHash(val);
  uint64_t converted_hash = static_cast<uint64_t>(hashVal);
  return converted_hash;
};

/** @brief calculate the register index */
template <typename KeyType>
auto HyperLogLogPresto<KeyType>::GetRegisterIndex(uint64_t &hashBit) -> uint16_t {
  int shift = BITSET_CAPACITY - this->lead_bit;
  return static_cast<uint16_t>(hashBit >> shift);
};

/** @brief Get previous value from overflow and current value bucket*/
template <typename KeyType>
auto HyperLogLogPresto<KeyType>::GetPrevValueAtRegisterIndex(uint16_t &registerIndex) -> int8_t {
  int8_t val = static_cast<int8_t>(this->dense_bucket_[registerIndex].to_ulong());
  if (this->overflow_bucket_.find(registerIndex) != this->overflow_bucket_.end()) {
    val = (static_cast<int8_t>(this->overflow_bucket_[registerIndex].to_ulong()) << DENSE_BUCKET_SIZE) | val;
  }
  return val;
}

/** @brief Get current value from the hashBit - LSBs */
template <typename KeyType>
auto HyperLogLogPresto<KeyType>::GetCurrentValue(uint64_t &hashbit) -> int8_t {
  int8_t count = 0;
  uint64_t mask = 1;
  while (count < BITSET_CAPACITY - this->lead_bit) {
    if (((hashbit >> count) & mask) == 1) break;
    count += 1;
  }
  return count;
}

/** @brief */
template <typename KeyType>
auto HyperLogLogPresto<KeyType>::UpdateValue(int8_t &curVal, uint16_t &registerIndex) -> void {
  std::bitset<DENSE_BUCKET_SIZE> val(curVal & 0x0F);
  this->dense_bucket_[registerIndex] = val;

  uint8_t overflowVal = curVal >> DENSE_BUCKET_SIZE;
  if (overflowVal > 0) {
    std::bitset<OVERFLOW_BUCKET_SIZE> overflow(overflowVal);
    this->overflow_bucket_[registerIndex] = overflow;
  }
}

/** @brief Element is added for HLL calculation. */
template <typename KeyType>
auto HyperLogLogPresto<KeyType>::AddElem(KeyType val) -> void {
  /** @TODO(student) Implement this function! */
  if (!this->valid_lead_bit) return;

  uint64_t bitHash = GetBitSetRepresentation(val);
  uint16_t registerIndex = GetRegisterIndex(bitHash);
  int8_t prevVal = GetPrevValueAtRegisterIndex(registerIndex);
  int8_t curVal = GetCurrentValue(bitHash);

  if (curVal > prevVal) UpdateValue(curVal, registerIndex);
}

/** @brief Function to compute cardinality. */
template <typename T>
auto HyperLogLogPresto<T>::ComputeCardinality() -> void {
  /** @TODO(student) Implement this function! */
  if (!this->valid_lead_bit) return;
  double sumValue = 0;
  double curVal;
  int bucketSize = this->dense_bucket_.size();
  for (uint16_t i = 0; i < bucketSize; i++) {
    curVal = std::pow(2, -GetPrevValueAtRegisterIndex(i));
    sumValue += curVal;
  }
  this->cardinality_ = (CONSTANT * bucketSize * bucketSize / sumValue);
}

template class HyperLogLogPresto<int64_t>;
template class HyperLogLogPresto<std::string>;
}  // namespace bustub
