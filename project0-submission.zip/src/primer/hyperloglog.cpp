//===----------------------------------------------------------------------===//
//
//                         BusTub
//
// hyperloglog.cpp
//
// Identification: src/primer/hyperloglog.cpp
//
// Copyright (c) 2015-2025, Carnegie Mellon University Database Group
//
//===----------------------------------------------------------------------===//

#include "primer/hyperloglog.h"

namespace bustub {

/** @brief Parameterized constructor. */
template <typename KeyType>
HyperLogLog<KeyType>::HyperLogLog(int16_t n_bits) : cardinality_(0) {
  // numbers of bits = n_bits
  // number of resgister = n_bits  ^ 2
  if (n_bits < 0 || n_bits >= BITSET_CAPACITY) {
    std::cerr << "b_bits must be a positive integer and less than BITSET_CAPACITY (64)." << std::endl;
    this->valid_leading_bit = false;
  } else {
    this->b_bits = n_bits;  // Ensures b_bits is at least 1
    this->m_register = 1 << n_bits;
    this->registers = std::vector<uint64_t>(m_register, 0);
    this->valid_leading_bit = true;
  }
}

/**
 * @brief Function that computes binary.
 *
 * @param[in] hash
 * @returns binary of a given hash
 */
template <typename KeyType>
auto HyperLogLog<KeyType>::ComputeBinary(const hash_t &hash) const -> std::bitset<BITSET_CAPACITY> {
  /** @TODO(student) Implement this function! */
  uint64_t converted_hash = static_cast<uint64_t>(hash);  // The hash value should be converted to a 64 bit binary
                                                          // stream
  return std::bitset<BITSET_CAPACITY>(converted_hash);
  // return {0};
}

/**
 * @brief Function that computes leading zeros.
 *
 * @param[in] bset - binary values of a given bitset
 * @returns leading zeros of given binary set
 */

template <typename KeyType>
auto HyperLogLog<KeyType>::PositionOfLeftmostOne(const std::bitset<BITSET_CAPACITY> &bset) const -> uint64_t {
  /** @TODO(student) Implement this function! */
  int start = BITSET_CAPACITY - b_bits;
  for (int i = start - 1; i >= 0; i--) {
    if (bset[i] == 1) {
      return start - i;
    }
  }
  return start;
}

template <typename KeyType>
auto HyperLogLog<KeyType>::GetRegisterIndex(const std::bitset<BITSET_CAPACITY> &bset) -> int32_t {
  int32_t index = 0;

  for (int i = BITSET_CAPACITY - 1; i >= BITSET_CAPACITY - this->b_bits; i--) {
    index = (index << 1) | bset[i];
  }
  return index;
};

/**
 * @brief Adds a value into the HyperLogLog.
 *
 * @param[in] val - value that's added into hyperloglog
 */
template <typename KeyType>
auto HyperLogLog<KeyType>::AddElem(KeyType val) -> void {
  /** @TODO(student) Implement this function! */

  /*
  1. Compute hash value
  2. Compute the binary representation of the hash value
  3. Get the register and the b_bit representation
  */
  if (!this->valid_leading_bit) return;
  hash_t curHashVal = CalculateHash(val);
  std::bitset<BITSET_CAPACITY> bitHash = ComputeBinary(curHashVal);
  int32_t registerIndex = GetRegisterIndex(bitHash);  // first b_bits of bithash
  uint64_t registerValue = PositionOfLeftmostOne(bitHash);
  this->registers[registerIndex] = std::max(this->registers[registerIndex], registerValue);
}

/**
 * @brief Function that computes cardinality.
 */
template <typename KeyType>
auto HyperLogLog<KeyType>::ComputeCardinality() -> void {
  /** @TODO(student) Implement this function! */
  if (!this->valid_leading_bit) return;

  double harmonic_total = 0.0;
  // Compute harmonic mean sum
  for (int i = 0; i < this->m_register; i++) {
    harmonic_total += 1 / std::pow(2, this->registers[i]);
  }
  cardinality_ = HyperLogLog::CONSTANT * this->m_register * (this->m_register / harmonic_total);
}

template class HyperLogLog<int64_t>;
template class HyperLogLog<std::string>;

}  // namespace bustub
